import streamlit as st

def check_zoning_eligibility(zoning, lot_size, frontage):
    responses = []

    # Dual Occupancy
    if zoning in ["R2", "R3", "R4"] and lot_size >= 450 and frontage >= 12:
        responses.append("✅ Dual Occupancy is permissible.")
    else:
        responses.append("❌ Dual Occupancy not permissible.")

    # Multi-Dwelling Housing
    if zoning in ["R2", "R3", "R4"] and lot_size >= 600 and frontage >= 18:
        responses.append("✅ Multi-Dwelling Housing is permissible.")
    else:
        responses.append("❌ Multi-Dwelling Housing not permissible.")

    # Terrace/Manor Homes
    if zoning in ["R2", "R3", "R4"] and lot_size >= 500 and frontage >= 15:
        responses.append("✅ Terrace/Manor Homes are permissible.")
    else:
        responses.append("❌ Terrace/Manor Homes not permissible.")

    # Residential Flat Building (RFB)
    if zoning in ["R3", "R4"]:
        responses.append("✅ Residential Flat Building is permissible.")
    else:
        responses.append("❌ Residential Flat Building not permissible.")

    # Shop Top Housing
    if zoning in ["R3", "R4", "E1"]:
        responses.append("✅ Shop Top Housing is permissible.")
    else:
        responses.append("❌ Shop Top Housing not permissible.")

    return "\n".join(responses)

# Streamlit GUI
st.set_page_config(page_title="NSW Zoning Checker", layout="centered")
st.title("🏗️ NSW Zoning Development Checker")

st.markdown("Enter property details below to check potential development types based on zoning.")

zoning = st.selectbox("Select Zoning Type", ["R1", "R2", "R3", "R4", "E1", "E2"])
lot_size = st.number_input("Lot Size (m²)", min_value=0.0, step=1.0)
frontage = st.number_input("Frontage (m)", min_value=0.0, step=0.1)

if st.button("Check Zoning Potential"):
    result = check_zoning_eligibility(zoning, lot_size, frontage)
    st.success("Zoning Analysis Result:")
    st.text(result)
