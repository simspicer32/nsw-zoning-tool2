# NSW Zoning Checker

This is a simple Streamlit app to check development potential for residential zoning in NSW.

## How to deploy

1. Upload to a GitHub repository
2. Go to [https://streamlit.io/cloud](https://streamlit.io/cloud)
3. Click 'New app'
4. Fill in:
   - Repository: yourusername/nsw-zoning-tool
   - Branch: main
   - Main file: zoning_checker.py
5. Click 'Deploy'
